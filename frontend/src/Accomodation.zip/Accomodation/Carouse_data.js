import img1 from './images/img1.png'
import img2 from './images/img2.png'
import img3 from './images/img3.png'

const data=[
    {
        id:1,
        img:img1,
        info:"Trident, Bhubaneswar is located approximately five kilometres from the central Bhubaneswar, 20 minutes from Biju Paitnaik international airport and close to many of the city’s top attractions."

    },{
        id:2,
        img:img2,
        info:"Enveloped in the lap of nature's breath-taking marvels, your stay with us is one of peace and unmatched privacy and plush comfort. Rooms are appointed keeping in mind the needs of the modern day traveller and luxury that our guests have always been accustomed to"
    },
    {
        id:3,
        img:img3,
        info:"As an oasis of unparalleled luxury combined with excellent service, you can surely find a tranquil corner within the premises to enjoy your holiday retreat to its maximum."
    },
    {
        id:4,
        img:img1,
        info:"Trident, Bhubaneswar is located approximately five kilometres from the central Bhubaneswar, 20 minutes from Biju Paitnaik international airport and close to many of the city’s top attractions."

    },{
        id:5,
        img:img2,
        info:"Enveloped in the lap of nature's breath-taking marvels, your stay with us is one of peace and unmatched privacy and plush comfort. Rooms are appointed keeping in mind the needs of the modern day traveller and luxury that our guests have always been accustomed to"
    },
    {
        id:6,
        img:img3,
        info:"As an oasis of unparalleled luxury combined with excellent service, you can surely find a tranquil corner within the premises to enjoy your holiday retreat to its maximum."
    }
]


export default data;
