import React from 'react'
import './acc.css'
import Carouseel from './Carouseel.js'

const acc = () => {
  return (
    <div className='accom-back'>
        <div className='accomodation'>
      <div ><p>Accommodation</p></div>
      </div>
      <Carouseel/>
    </div>
  )
}

export default acc
